$(document).ready(function () {
    $(".remove").click(function () {
        $(this).parents('.card').hide();
    });
});